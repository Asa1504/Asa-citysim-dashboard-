function randomPercent() {
  return Math.floor(Math.random() * 100);
}

function updateDashboard() {
  // Power
  let power = randomPercent();
  document.getElementById("power-bar").style.width = power + "%";
  document.getElementById("power-text").innerText =
    power > 70 ? "High Usage" : power > 40 ? "Moderate" : "Normal";

  // Traffic
  let traffic = randomPercent();
  document.getElementById("traffic-bar").style.width = traffic + "%";
  document.getElementById("traffic-text").innerText =
    traffic > 70 ? "Heavy Congestion" : traffic > 40 ? "Busy" : "Smooth";

  // Crime
  let crime = randomPercent();
  document.getElementById("crime-bar").style.width = crime + "%";
  document.getElementById("crime-text").innerText =
    crime > 70 ? "High Risk" : crime > 40 ? "Moderate" : "Low";
}

// Update every 3 seconds
setInterval(updateDashboard, 3000);
updateDashboard();
